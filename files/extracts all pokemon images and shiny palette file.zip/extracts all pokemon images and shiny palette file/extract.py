import os
import re
import shutil

def extract_5bit_from_txt(filepath):
    """Reads a shiny.pal .txt file and extracts the two RGB tuples."""
    colors = []
    with open(filepath, 'r') as file:
        for line in file:
            match = re.match(r"\s*RGB\s+(\d+),\s*(\d+),\s*(\d+)", line)
            if match:
                r, g, b = map(int, match.groups())
                colors.append((r, g, b))
    if len(colors) != 2:
        raise ValueError(f"{filepath}: Expected exactly 2 RGB color lines, found {len(colors)}")
    return colors

def process_all_shiny_text_palettes(base_folder, output_txt_path, sprite_output_folder):
    results = []

    if not os.path.exists(sprite_output_folder):
        os.makedirs(sprite_output_folder)

    # Preload the shared Unown palette if available
    unown_palette_path = os.path.join(base_folder, "unown", "shiny.pal")
    unown_colors = None
    if os.path.exists(unown_palette_path):
        unown_colors = extract_5bit_from_txt(unown_palette_path)

    for root, dirs, files in os.walk(base_folder):
        for file in files:
            if file == "front.png":
                raw_name = os.path.basename(root)

                # Determine which shiny.pal to use
                if raw_name.startswith("unown_"):
                    if unown_colors is None:
                        print(f"[WARN] No base shiny.pal found for unown, skipping {raw_name}")
                        continue
                    colors = unown_colors
                else:
                    pal_path = os.path.join(root, "shiny.pal")
                    if not os.path.exists(pal_path):
                        print(f"[WARN] No shiny.pal for {raw_name}")
                        continue
                    try:
                        colors = extract_5bit_from_txt(pal_path)
                    except Exception as e:
                        print(f"Error processing {pal_path}: {e}")
                        continue

                # Append result
                results.append(f"{raw_name}: {colors}")

                # Copy front.png
                sprite_path = os.path.join(root, file)
                dest_path = os.path.join(sprite_output_folder, f"{raw_name}.png")
                shutil.copyfile(sprite_path, dest_path)

    with open(output_txt_path, 'w') as f:
        for line in sorted(results):
            f.write(line + "\n")

# Set your paths
base_dir = r"pokecrystal\\gfx\\pokemon"
output_file = "shiny_palettes.txt"
sprite_folder = "sprites"

# Run the process
process_all_shiny_text_palettes(base_dir, output_file, sprite_folder)
print("Extraction complete. Palettes saved to:", output_file)
print("Sprites copied to:", sprite_folder)
